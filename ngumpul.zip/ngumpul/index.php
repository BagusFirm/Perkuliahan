<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ngumpul</title>
	<link rel="stylesheet" type="text/css" href="css/tampilan.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/js1.js"></script>
</head>
<body>
	<!-- header -->
	<div class="box-head">
		<div class="ktk-kpla">
			<div class="logo">
				<img src="img/logo.png">
			</div>
			<div class="cari-bar">
				<input type="text" name="kata_cari" placeholder="Cari Orang" value="">
				<i class="glyphicon glyphicon-search"></i>
			</div>
			<div class="info-pndek">
				<a class="menu-item1" href="">
					<div class="menu-item1-box">
						<span class="glyphicon glyphicon-plus"></span>
					</div>
				</a>
				<a class="menu-item2" href="">
					<div class="menu-item1-box">
						<span class="glyphicon glyphicon-bell"></span>
					</div>
				</a>
				<a class="menu-item3" href="">
					<div class="menu-item1-box">
						<span class="glyphicon glyphicon-send"></span>
					</div>
				</a>
				<a class="menu-item4" href="">
					<div class="menu-item1-box">
						<span class="glyphicon glyphicon-th"></span>
					</div>
				</a>
			</div>
		</div>
		<div class="icon-down">
			<span class="glyphicon glyphicon-menu-down"></span>
		</div>
		<div class="menu-pilih">
				<a class="aktif menu-pilih1" href="../perkuliahan/index.php" target="#page-posting">
					<div class="menu-pilih1-box">
						<span class="glyphicon glyphicon-home"></span>
					</div>
				</a>
				<a class="menu-pilih2" href="">
					<div class="menu-pilih2-box">
						<span class="glyphicon glyphicon-facetime-video"></span>
					</div>
				</a>
				<a class="menu-pilih3" href="">
					<div class="menu-pilih3-box">
						<span class="glyphicon glyphicon-briefcase"></span>
					</div>
				</a>
				<a class="menu-pilih4" href="">
					<div class="menu-pilih4-box">
						<span class="glyphicon glyphicon-shopping-cart"></span>
					</div>
				</a>
				<div class="icon-up">
					<i class="glyphicon glyphicon-menu-up"></i>
				</div>
			</div>
	</div>
	<!-- akhir header -->
	<!-- konten -->
	<div class="halaman-utama">
		<div class="menu1 fixed-menu">
			<h1 class="jdul-menu1">Home</h1>
			<div class="menu1-isi">
				<a href="#"><p><span class="glyphicon glyphicon-flag iconcolor-default"></span>Halaman</p></a>
				<a href="#"><p><span class="glyphicon glyphicon-book iconcolor-buku"></span>Buku</p></a>
				<a href="#"><p><span class="glyphicon glyphicon-heart-empty iconcolor-heart"></span>Covid 19</p></a>
				<a href="#"><p><span class="glyphicon glyphicon-briefcase iconcolor-default"></span>Jobs</p></a>
				<a href="#"><p><span class="glyphicon glyphicon-user iconcolor-default"></span>Friends</p></a>
				<a href="#"><p><span class="glyphicon glyphicon-bookmark iconcolor-simpan"></span>Simpan</p></a>
			</div>
		</div>
		<div class="menu2 fixed-menu">
			<h1 class="jdul-menu2">Friend</h1>
		</div>
		<div class="page-post">
			<div class="isi-post">
				<div class="cerita">
					<h1 class="jdul-post">Cerita : </h1>
				</div>
			</div>
		</div>
	</div>
	<!-- akhir konten -->
</body>
</html>
// aksi menu pilih
  document.addEventListener("DOMContentLoaded", function () {
    const iconDown = document.querySelector(".icon-down");
    const menuPilih = document.querySelector(".menu-pilih");
    const iconUp = document.querySelector(".icon-up");

    iconDown.addEventListener("click", function () {
      menuPilih.classList.toggle("active");
      iconUp.classList.toggle("active");
    });

    iconUp.addEventListener("click", function () {
      menuPilih.classList.remove("active");
      iconUp.classList.remove("active");
    });
  });
<?php
$host = "localhost"; // Nama host database
$username = "username"; // Username database
$password = "password"; // Password database
$database = "nama_database"; // Nama database

// Membuat koneksi
$koneksi = new mysqli($host, $username, $password, $database);

// Memeriksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi database gagal: " . $koneksi->connect_error);
}

// Cek apakah ada data yang dikirim melalui form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $no = $_POST['no'];
    $hari = $_POST['hari'];
    $waktu = $_POST['waktu'];
    $mata_kuliah = $_POST['mata_kuliah'];
    $ruang = $_POST['ruang'];
    $sks = $_POST['sks'];
    $dosen = $_POST['dosen'];

    // Update data ke database
    $sql = "UPDATE jadwal_kuliah SET hari='$hari', waktu='$waktu', mata_kuliah='$mata_kuliah', ruang='$ruang', sks='$sks', dosen='$dosen' WHERE no='$no'";
    if ($koneksi->query($sql) === TRUE) {
        echo "Data berhasil diperbarui";
    } else {
        echo "Terjadi kesalahan: " . $koneksi->error;
    }
}

// Mendapatkan data entri yang akan diedit
$no = $_GET['no'];
$sql = "SELECT * FROM jadwal_kuliah WHERE no='$no'";
$result = $koneksi->query($sql);
$row = $result->fetch_assoc();

// Menutup koneksi
$koneksi->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Jadwal Kuliah</title>
</head>
<body>
    <h1>Edit Jadwal Kuliah</h1>
    <form method="POST" action="">
        <input type="hidden" name="no" value="<?php echo $row['no']; ?>">
        <label for="hari">Hari:</label>
        <input type="text" name="hari" value="<?php echo $row['hari']; ?>"><br>
        <label for="waktu">Waktu:</label>
        <input type="text" name="waktu" value="<?php echo $row['waktu']; ?>"><br>
        <label for="mata_kuliah">Mata Kuliah:</label>
        <input type="text" name="mata_kuliah" value="<?php echo $row['mata_kuliah']; ?>"><br>
        <label for="ruang">Ruang:</label>
        <input type="text" name="ruang" value="<?php echo $row['ruang']; ?>"><br>
        <label for="sks">SKS:</label>
        <input type="text" name="sks" value="<?php echo $row['sks']; ?>"><br>
        <label for="dosen">Dosen:</label>
        <input type="text" name="dosen" value="<?php echo $row['dosen']; ?>"><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Perkuliahan</title>
	<link rel="icon" type="image/x-icon" href="img/logo.png">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/uicons-solid-rounded.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</head>
<body>
	<div class="box-tab">
		<div class="padd-menu">
			<div class="menu-box">
				<input type="checkbox" id="box-menu">
				<label class="ktk" for="box-menu">
					<span></span>
					<span></span>
					<span></span>
				</label>
				<ul class="menu">
					<li><a href="materi">Web Design</a></li>
					<li><a href="#">Visual Basic</a></li>
					<li><a href="#">Myob Accounting</a></li>
					<li><a href="#">B.Inggris</a></li>
				</ul>
			</div>
		</div>
		<h1 class="jdul-utama">PERKULIAHAN</h1>
		<div class="favicon1" >
			<a href="#">
				<span class="ico-1"><i class="fi fi-sr-portal-exit"></i></span>
				<div class="outlog-div">
					<span class="outlog">Logout</span>
				</div>
			</a>
		</div>
	</div>
	<div class="konten">
		<div class="box-prop">
			<h2 class="jdul-kedua">Jadwal Perkuliahan</h2>
		</div>
		<hr class="hr-garis1">
		<div class="box-table">
			<table class="table table-animated table-radius table-hover table-striped">
				<thead class="table-jdul">
					<tr>
						<th>No</th>
						<th>Hari</th>
						<th>Waktu</th>
						<th>Mata Kuliah</th>
						<th>Ruang</th>
						<th>SKS</th>
						<th>Dosen</th>
					</tr>
				</thead>
				<?php 
				include('kontrol/aksi_view_jadwal.php')
				?>
			</table>
		</div>
	</div>
	<div class="box-prop">
		<h2 class="jdul-kedua">Catatan</h2>
	</div>
	<hr class="hr-garis1">
	<div class="box-note">
		<h1 class="jdul-note">Catatan</h1>
		<form class="note-form" id="note-form">
			<input type="text" name="isi-note" placeholder=" Judul Catatan">
			<hr class="hr-garis3">
			<textarea class="note" placeholder=" Isi Catatan"></textarea>
			<button class="btn btn-note" type="submit">Simpan</button>
		</form>
	</div>
</div>
<div class="box-prop">
	<h2 class="jdul-kedua">List Note</h2>
</div>
<hr class="hr-garis1">
<div class="box-table">
</div>
</div>
</body>
<footer>
	<p class="foot">&#169; Copyright | 2023 Bagus Firmansyah&#8482;</p>
</footer>
</html>
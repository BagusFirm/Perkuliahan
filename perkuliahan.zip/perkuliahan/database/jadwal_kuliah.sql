-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2023 at 10:55 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perkuliahan`
--

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_kuliah`
--

CREATE TABLE `jadwal_kuliah` (
  `no` int(11) NOT NULL,
  `hari` varchar(20) DEFAULT NULL,
  `waktu` time DEFAULT NULL,
  `waktu2` time DEFAULT NULL,
  `waktu3` time DEFAULT NULL,
  `waktu4` time DEFAULT NULL,
  `mata_kuliah` varchar(100) DEFAULT NULL,
  `mata_kuliah2` varchar(255) DEFAULT NULL,
  `ruang` varchar(50) DEFAULT NULL,
  `ruang2` varchar(255) DEFAULT NULL,
  `sks` int(11) DEFAULT NULL,
  `sks2` int(11) DEFAULT NULL,
  `dosen` varchar(100) DEFAULT NULL,
  `dosen2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal_kuliah`
--

INSERT INTO `jadwal_kuliah` (`no`, `hari`, `waktu`, `waktu2`, `waktu3`, `waktu4`, `mata_kuliah`, `mata_kuliah2`, `ruang`, `ruang2`, `sks`, `sks2`, `dosen`, `dosen2`) VALUES
(1, 'Senin', '16:30:00', '17:50:00', '18:30:00', '19:50:00', 'Pemrograman Visual Basic (VB 6.0)', 'Manajemen Keuangan', 'Lab', 'A', 2, 2, 'Mukhfid, M.Kom', 'Hadi Santosa, SE. MM '),
(2, 'Selasa', '16:30:00', '17:50:00', '18:30:00', '19:50:00', 'Aplikasi Komputer Akuntansi( Myob )', 'PPA II ( Visio & Access )', 'Lab', 'Lab', 2, 2, 'Soipah, M.Kom', 'Mukhfid, M.Kom'),
(3, 'Rabu', '16:30:00', '17:50:00', '18:30:00', '19:50:00', 'Pendidikan Pancasila', 'Organisasi Komputer', 'C', 'C', 2, 2, 'Affy Khoiriyah, Lc.Msi', 'Dedi Santosa. M.Kom'),
(4, 'Kamis', '16:30:00', '17:50:00', '18:30:00', '19:50:00', 'Pemrograman WEB I (Interface)', 'Pend. Bhs Inggris  2', 'Lab', 'C', 2, 2, 'Adi Duryadi, M.Kom', 'Maelasari, S.Pd'),
(5, 'Jum\'at', '16:30:00', '17:50:00', NULL, NULL, 'Algoritma & Struktur Data (Bhs Java)', NULL, 'Lab', NULL, 2, NULL, 'Tias Beni Purabaya, M.Kom', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jadwal_kuliah`
--
ALTER TABLE `jadwal_kuliah`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jadwal_kuliah`
--
ALTER TABLE `jadwal_kuliah`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

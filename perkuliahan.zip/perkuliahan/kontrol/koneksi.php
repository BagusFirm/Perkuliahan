<?php 

	$databaseHost = 'localhost';
	$databaseName = 'db_perkuliahan';
	$databaseUsername = 'root';
	$databasePassword = '';
	 
	$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

 ?>
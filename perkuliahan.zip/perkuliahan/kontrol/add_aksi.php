<?php
include_once("koneksi.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hari = $_POST['hari'];
    $waktu = $_POST['waktu'];
    $mata_kuliah = $_POST['mata_kuliah'];
    $ruang = $_POST['ruang'];
    $sks = $_POST['sks'];
    $dosen = $_POST['dosen'];

    $sql = "INSERT INTO jadwal_kuliah (hari, waktu, mata_kuliah, ruang, sks, dosen) VALUES ('$hari', '$waktu', '$mata_kuliah', '$ruang', '$sks', '$dosen')";
    if ($mysqli->query($sql) === TRUE) {
        echo "Data berhasil ditambahkan";
    } else {
        echo "Terjadi kesalahan: " . $mysqli->error;
    }
}

?>
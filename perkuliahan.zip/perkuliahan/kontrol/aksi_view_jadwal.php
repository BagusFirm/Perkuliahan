<?php
include_once("koneksi.php");


$sql = "SELECT * FROM jadwal_kuliah";
$result = $mysqli->query($sql);

while ($row = $result->fetch_assoc()) : ?>
	<tbody>
		<tr>
			<td rowspan="2"><?php echo $row['no']; ?></td>
			<td rowspan="2"><?php echo $row['hari']; ?></td>
			<td>
				<?php echo date('H:i', strtotime($row['waktu'])); ?>
				<?php if (!empty($row['waktu2'])) : ?>
					- <?php echo date('H:i', strtotime($row['waktu2'])); ?>
				<?php endif; ?>
			</td>
			<td><?php echo $row['mata_kuliah']; ?></td>
			<td><?php echo $row['ruang']; ?></td>
			<td><?php echo $row['sks']; ?></td>
			<td><?php echo $row['dosen']; ?></td>
		</tr>
		<?php if (!empty($row['waktu3']) && !empty($row['waktu4'])) : ?>
		<tr>
			<td>
				<?php echo date('H:i', strtotime($row['waktu3'])); ?>
				<?php if (!empty($row['waktu4'])) : ?>
					- <?php echo date('H:i', strtotime($row['waktu4'])); ?>
				<?php endif; ?>
			</td>
			<td><?php echo $row['mata_kuliah2']; ?></td>
			<td><?php echo $row['ruang2']; ?></td>
			<td><?php echo $row['sks2']; ?></td>
			<td><?php echo $row['dosen2']; ?></td>
		</tr>
	<?php endif; ?>
</tbody>
<?php endwhile; ?>